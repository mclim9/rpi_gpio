# Wiring Pi 2

This package has been deprecated in favour of using the name "WiringPi" which provides the same exact functionality.
